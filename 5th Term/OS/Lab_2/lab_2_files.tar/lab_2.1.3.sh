#!/bin/bash

if [ $# != 0 ]; then
        if [ $1 == 'verbose' ]; then
                set -x
        elif [ $1 == '-v' ]; then
                set -x
        fi
fi

cd /home/student

if [ ! -d ./good_films ]; then
	echo "Directory 'good_films' does not exist. Please, run ./lab_2.1.2.sh"
	exit 1
else
	echo "Directory 'good_films' exists."
fi

echo "Renaming good_films folder into bad_films"
mv good_films/ bad_films/
#cat ./bad_films/cars.txt

if [ -f ./bad_films/cars.txt ]; then
	cd ./bad_films
	mv cars.txt the_substance.txt
	echo -e "2024\nWorking Title Films\nCoralie Fargeat" > the_substance.txt
else
	echo "cars.txt was not moved successfuly!"
fi
