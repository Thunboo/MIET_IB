#!/bin/bash

if [ $# != 0 ]; then
        if [ $1 == 'verbose' ]; then
                set -x
        elif [ $1 == '-v'  ]; then
                set -x
        fi
fi


cd /home/student

if [ ! -d ./Lab_2 ] || [ ! -d ./Lab_2/books ]; then
	echo "Directory 'Lab_2' or 'Lab_2/books' does not exist. Please, run ./lab_2.1.1.sh"
	exit 1
else
	echo "Directory 'Lab_2' exists."
fi

cd ./Lab_2

if [ ! -d ./Lab_2/good_films ]; then
	echo "Directory 'Lab_2/good_films' does not exist. Creating..."
	mkdir good_films

	echo "Moving cars.txt from books into good_films folder..."
	mv ./books/cars.txt ./good_films/cars.txt

	echo "Removing books folder"
	rm -rf ./books

	echo "Copying good_films into /home/student folder..."
	cp -r ./good_films/ /home/student/good_films/
fi
