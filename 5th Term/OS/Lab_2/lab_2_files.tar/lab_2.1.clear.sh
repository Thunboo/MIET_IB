#!/bin/bash

if [ $# != 0 ]; then
	if [ $1 == 'verbose' ]; then
		set -x
	elif [ $1 == '-v'  ]; then
		set -x
	fi
fi

rm -rf /home/student/Lab_2/

rm -rf /home/student/good_films/

rm -rf /home/student/bad_films/

