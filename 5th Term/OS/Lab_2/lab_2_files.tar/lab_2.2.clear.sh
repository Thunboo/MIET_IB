#!/bin/bash

if [ $# != 0 ]; then
	if [ $1 == 'verbose' ]; then
		set -x
	elif [ $1 == '-v'  ]; then
		set -x
	fi
fi

sudo umount /home/student/Lab_2/new_dir

rm -rf /home/student/Lab_2/
