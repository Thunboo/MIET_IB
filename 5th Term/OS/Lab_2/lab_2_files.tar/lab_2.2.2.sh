#!/bin/bash

if [ $# != 0 ]; then
        if [ $1  == 'verbose' ]; then
                set -x
        elif [ $1  == '-v'  ]; then
                set -x
        fi
fi


cd /home/student

if [ -d ./Lab_2 ]; then
	cd ./Lab_2/
else
	echo "Directory 'Lab_2' does not exist. First run lab_2.2.1.sh"
	exit 1
fi

mkdir new_dir
sudo mount ./file.img ./new_dir

echo "Checking mount:"
df -Th

cd ./new_dir
echo "Writing and reading several files in new FS"

sudo dd if=/dev/zero of=test.img bs=b count=10
sudo head -n 8 test.img

sudo echo -e "text\ntext" > text.txt

sudo ls -l
