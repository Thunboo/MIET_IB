#!/bin/bash

if [ $# != 0 ]; then
        if [ $1 == 'verbose' ]; then
                set -x
        elif [ $1 == '-v' ]; then
                set -x
        fi
fi

cd /home/student

if [ ! -d ./bad_films ]; then
	echo "Directory 'bad_films' does not exist. Please, run ./lab_2.1.3.sh"
	exit 1
else
	echo "Directory 'bad_films' exists."
fi

cd ./bad_films/


#####

echo -e "\n----"
echo "Creating hard and soft links to the_substance.txt..."
ln ./the_substance.txt hardlink
ln -s ./the_substance.txt softlink

echo -e "\nHardlink output:"
cat ./hardlink
echo -e "\nSoftlink output:"
cat ./softlink

#####

echo -e "\n----"

cd ../

if [ ! -d ./good_films ]; then
	echo "No /good_films directory was not found. Creating one..."
	mkdir good_films
else
	echo "/good_films directory exists"
fi

echo "Moving original file from /bad_films to /good_films directory..."
mv ./bad_films/the_substance.txt ./good_films/the_substance.txt

echo -e "\nHardlink output:"
cat ./bad_films/hardlink
echo -e "\nSoftlink output:"
cat ./bad_films/softlink

#####

echo -e "\n----"
echo "Deleting original file from /good_films directory..."
rm -f ./good_films/the_substance.txt

echo -e "\nHardlink output:"
cat ./bad_films/hardlink
echo -e "\nSoftlink output:"
cat ./bad_films/softlink
