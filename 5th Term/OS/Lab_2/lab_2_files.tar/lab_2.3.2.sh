#!/bin/bash

if [ $# != 0 ]; then
        if [ $1  == 'verbose' ]; then
                set -x
        elif [ $1  == '-v'  ]; then
                set -x
        fi
fi


cd /home/student

if [ -d ./good_music ]; then
	echo "Directory 'good_music' exists."
else
	echo "Directory 'good_music' does not exist. Creating..."
	mkdir good_music
fi
cd ./good_music/

echo "Creating music files..."
cp ~/lab_scripts/lab_2/music_txts/* .

ls -li ~ | grep good_music
ls -li
