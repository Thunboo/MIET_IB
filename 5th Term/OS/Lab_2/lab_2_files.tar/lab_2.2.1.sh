#!/bin/bash

if [ $# != 0 ]; then
        if [ $1  == 'verbose' ]; then
                set -x
        elif [ $1  == '-v'  ]; then
                set -x
        fi
fi


cd /home/student

if [ -d ./Lab_2 ]; then
	echo "Directory 'Lab_2' exists."
else
	echo "Directory 'Lab_2' does not exist. Creating..."
	mkdir Lab_2
fi
cd ./Lab_2/

touch file.img

# if = источник копирования
# of = место назначения
# bs = b -> по 512 байт
# count = 200 -> 200 раз по bs=b -> 512b * 200 = 100 KiB
dd if=/dev/zero of=file.img bs=b count=200

#sudo mkfs.vfat -F 32 -n 'lab_2_2' file.img
sudo mkfs.vfat -n 'LAB_2_2' file.img
