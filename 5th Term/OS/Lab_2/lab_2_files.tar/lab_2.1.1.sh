#!/bin/bash

if [ $# != 0 ]; then
        if [ $1  == 'verbose' ]; then
                set -x
        elif [ $1  == '-v'  ]; then
                set -x
        fi
fi


cd /home/student

if [ -d ./Lab_2 ]; then
	echo "Directory 'Lab_2' exists."
else
	echo "Directory 'Lab_2' does not exist. Creating..."
	mkdir Lab_2
	cd ./Lab_2/

	echo "Creating ./Lab_2/books/ directory..."
	mkdir books
	cd ./books/

	echo "Creating ./Lab_2/books/cars.txt file..."
	touch cars.txt
	echo -e "2007\nPixar/Disney\nJohn Lasseter" > cars.txt

	echo "$ cat ./Lab_2/books/cars.txt"
	cat cars.txt
fi
