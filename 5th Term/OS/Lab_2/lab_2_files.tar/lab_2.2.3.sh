#!/bin/bash

echo "if you have permission issues - run this script with sudo"

if [ $# != 0 ]; then
        if [ $1  == 'verbose' ]; then
                set -x
        elif [ $1  == '-v'  ]; then
                set -x
        fi
fi

cd /home/student

if [ -d ./Lab_2 ]; then
	cd ./Lab_2/
else
	echo "Directory 'Lab_2' does not exist. First run lab_2.2.1.sh"
	exit 1
fi

if [ -d ./new_dir ]; then
	cd ./new_dir/
else
	echo "Directory 'new_dir' does not exist. First run lab_2.2.2.sh"
	exit 1
fi

if [ -f text.txt ]; then
	for i in {1..5}; do
		target="text$i.txt"
		cp text.txt "$target"
	done

	tar -cf archive.tar text1.txt text2.txt text3.txt text4.txt text5.txt --remove-files
	ls -lh

	gzip archive.tar
	ls -lh

	gunzip archive.tar.gz
	ls -lh

	tar -xvf archive.tar
	ls -lh
fi
