#!/bin/bash

cd /home/student

#set -x

folder_inode=$(ls -i ~ | grep music | awk '{print $1}')
find . -inum $folder_inode -exec ls {} \;

for file_inode in $(ls -i ~/good_music/* | awk '{print $1}'); do
	echo -e '----\n'
	find . -inum $file_inode -exec tail -n 5 {} \;


done
